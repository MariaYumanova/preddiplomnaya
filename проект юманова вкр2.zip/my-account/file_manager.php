<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Проверка авторизации администратора
if (empty($_COOKIE['user']) || $_COOKIE['user'] != 'admin1') {
    die("Доступ запрещен. Требуется авторизация администратора.");
}

// Базовая директория - корень сайта
$base_dir = $_SERVER['DOCUMENT_ROOT'];

// Получаем текущую папку из GET параметра
$current_dir = isset($_GET['dir']) ? $base_dir . '/' . $_GET['dir'] : $base_dir;

// Проверяем что папка существует и находится внутри базовой директории
if (!is_dir($current_dir) || strpos(realpath($current_dir), realpath($base_dir)) !== 0) {
    $current_dir = $base_dir;
}

// Функция для рекурсивного удаления папки с содержимым
function deleteFolder($folderPath) {
    if (!is_dir($folderPath)) {
        return false;
    }

    $files = array_diff(scandir($folderPath), ['.', '..']);

    foreach ($files as $file) {
        $path = $folderPath . '/' . $file;

        if (is_dir($path)) {
            deleteFolder($path);
        } else {
            unlink($path);
        }
    }

    return rmdir($folderPath);
}

// Обработка действий с файлами
if (isset($_GET['action']) && isset($_GET['file'])) {
    $file_path = $base_dir . '/' . $_GET['file'];

    // Проверка безопасности
    if (file_exists($file_path) && strpos(realpath($file_path), realpath($base_dir)) === 0) {
        switch ($_GET['action']) {
            case 'download':
                header('Content-Type: application/octet-stream');
                header('Content-Disposition: attachment; filename="' . basename($file_path) . '"');
                readfile($file_path);
                exit;

            case 'view':
                if (is_file($file_path)) {
                    $extension = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
                    if (in_array($extension, ['txt', 'csv', 'html', 'htm', 'css', 'js', 'php', 'json', 'xml'])) {
                        header('Content-Type: text/plain; charset=utf-8');
                        readfile($file_path);
                        exit;
                    }
                }
                break;

            case 'delete':
                if (is_file($file_path)) {
                    // Удаление файла
                    unlink($file_path);
                } elseif (is_dir($file_path)) {
                    // Удаление папки с содержимым
                    deleteFolder($file_path);
                }
                header('Location: ' . $_SERVER['PHP_SELF'] . '?dir=' . urlencode($_GET['dir'] ?? ''));
                exit;
                break;
        }
    }
}

// Загрузка файлов
if (isset($_POST['upload']) && isset($_FILES['file'])) {
    $target_file = $current_dir . '/' . basename($_FILES['file']['name']);
    if (move_uploaded_file($_FILES['file']['tmp_name'], $target_file)) {
        header('Location: ' . $_SERVER['PHP_SELF'] . '?dir=' . urlencode($_GET['dir'] ?? ''));
        exit;
    }
}

// Создание папки
if (isset($_POST['create_folder']) && !empty($_POST['folder_name'])) {
    $new_folder = $current_dir . '/' . $_POST['folder_name'];
    if (!file_exists($new_folder)) {
        mkdir($new_folder, 0755);
        header('Location: ' . $_SERVER['PHP_SELF'] . '?dir=' . urlencode($_GET['dir'] ?? ''));
        exit;
    }
}

// Получаем список файлов и папок
$files = scandir($current_dir);
$files = array_diff($files, ['.', '..']);

// Функция для форматирования размера
function formatSize($bytes) {
    if ($bytes == 0) return '0 B';
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = floor(log($bytes, 1024));
    return round($bytes / pow(1024, $i), 2) . ' ' . $units[$i];
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Файловый менеджер — Student IT Community</title>
  <link rel="stylesheet" href="/style.css">
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }

        h1 { color: #2c3e50; text-align: center; }
        .breadcrumb { background: #e8f4f8; padding: 10px; border-radius: 5px; margin: 15px 0; }
        .breadcrumb a { color: #3498db; text-decoration: none; }
        .file-list { list-style: none; padding: 0; margin: 20px 0; }
        .file-item { padding: 12px; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center; }
        .file-item:hover { background: #f8f9fa; }
        .file-icon { margin-right: 10px; font-size: 18px; }
        .folder { color: #2c3e50; font-weight: bold; text-decoration: none; font-size: 16px; }
        .file-actions { display: flex; gap: 8px; }
        .btn { padding: 6px 12px; border-radius: 4px; text-decoration: none; font-size: 13px; border: none; cursor: pointer; }
        .btn-view { background: #3498db; color: white; }
        .btn-download { background: #27ae60; color: white; }
        .btn-delete { background: #e74c3c; color: white; }
        .upload-form, .create-folder { background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0; }
        .file-info { font-size: 12px; color: #7f8c8d; margin-top: 5px; }
        .debug-info { background: #ffeaa7; padding: 15px; border-radius: 5px; margin: 15px 0; font-family: monospace; }
        input[type="file"], input[type="text"] { padding: 8px; border: 1px solid #ddd; border-radius: 4px; margin: 5px 0; }
        button { background: #3498db; color: white; padding: 10px 15px; border: none; border-radius: 4px; cursor: pointer; }
        button:hover { background: #2980b9; }
    </style>
</head>

<body>
  <header class="site-header">
      <div class="container">
          <div class="header-inner">
              <div class="site-branding">
                  <p class="site-title"><a href="/" rel="home">Student IT Community</a></p>
              </div>

              <nav class="main-nav">
                  <ul>
                      <li><a href="/">Главная</a></li>
                      <li><a href="/news/">Новости</a></li>
                      <li><a href="/shop/">Магазин</a></li>
                      <li><a href="/a5213-contact/">Контакты</a></li>
                      <li><a href="/%d0%be-%d1%81%d0%be%d0%be%d0%b1%d1%89%d0%b5%d1%81%d1%82%d0%b2%d0%b5/">О сообществе</a></li>
                      <li><a href="/my-account/">Мой аккаунт</a></li>
                      <li><a href="/cart/">Корзина</a></li>
                  </ul>
              </nav>
          </div>
      </div>
  </header>


  <main class="container">
    <div class="breadcrumb">
        <a href="/">Главная</a> > Файловый менеджер
    </div>
		<header class="entry-header">
			<h1 class="page-title">Файловый менеджер</h1>
		</header>
		<div class="main-content">

			<div class="entry-content">

					<h2 class="poll-title">Файловый менеджер</h2>

    <div class="container">
        <h1>📁 Файловый менеджер</h1>

        <div class="debug-info">
            <strong>Информация для отладки:</strong><br>
            Текущая папка: <?= $current_dir ?><br>
            GET dir: <?= $_GET['dir'] ?? 'не указан' ?><br>
            Количество элементов: <?= count($files) ?><br>
            Базовая папка: <?= $base_dir ?>
        </div>

        <div class="breadcrumb">
            <a href="?">Корень сайта</a>
            <?php
            if (isset($_GET['dir'])) {
                $parts = explode('/', $_GET['dir']);
                $current_path = '';
                foreach ($parts as $part) {
                    $current_path .= $current_path ? '/' . $part : $part;
                    echo ' / <a href="?dir=' . urlencode($current_path) . '">' . $part . '</a>';
                }
            }
            ?>
        </div>

        <div>
            <h2>Содержимое папки: <?= basename($current_dir) ?></h2>

            <?php if (empty($files)): ?>
                <p>Папка пуста</p>
            <?php else: ?>
                <ul class="file-list">
                    <?php foreach ($files as $file): ?>
                    <?php
                    $file_path = $current_dir . '/' . $file;
                    $is_dir = is_dir($file_path);
                    $file_size = $is_dir ? '' : formatSize(filesize($file_path));
                    $modified = date('d.m.Y H:i', filemtime($file_path));

                    // Формируем относительный путь для ссылок
                    $relative_path = '';
                    if (isset($_GET['dir'])) {
                        $relative_path = $_GET['dir'] . '/' . $file;
                    } else {
                        $relative_path = $file;
                    }
                    ?>
                    <li class="file-item">
                        <div>
                            <span class="file-icon"><?= $is_dir ? '📁' : '📄' ?></span>
                            <?php if ($is_dir): ?>
                                <a href="?dir=<?= urlencode($relative_path) ?>" class="folder">
                                    <?= $file ?>
                                </a>
                            <?php else: ?>
                                <span><?= $file ?></span>
                            <?php endif; ?>
                            <div class="file-info">
                                <?php if (!$is_dir): ?>
                                    Размер: <?= $file_size ?> |
                                <?php endif; ?>
                                Изменен: <?= $modified ?>
                            </div>
                        </div>
                        <div class="file-actions">
                            <?php if (!$is_dir): ?>
                                <a href="?action=view&file=<?= urlencode($relative_path) ?>&dir=<?= urlencode($_GET['dir'] ?? '') ?>" class="btn btn-view">Просмотр</a>
                                <a href="?action=download&file=<?= urlencode($relative_path) ?>&dir=<?= urlencode($_GET['dir'] ?? '') ?>" class="btn btn-download">Скачать</a>
                            <?php endif; ?>
                            <a href="?action=delete&file=<?= urlencode($relative_path) ?>&dir=<?= urlencode($_GET['dir'] ?? '') ?>"
                               class="btn btn-delete"
                               onclick="return confirm('<?= $is_dir ? 'ВНИМАНИЕ: Будет удалена вся папка со всеми файлами внутри! Удалить папку ' . $file . '?' : 'Удалить файл ' . $file . '?' ?>')">
                               Удалить
                            </a>
                        </div>
                    </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>

        <div class="upload-form">
            <h3>📤 Загрузить файл</h3>
            <form method="post" enctype="multipart/form-data">
                <input type="file" name="file" required style="display: block; margin: 10px 0;">
                <button type="submit" name="upload">Загрузить файл</button>
            </form>
        </div>

        <div class="create-folder">
            <h3>📂 Создать папку</h3>
            <form method="post">
                <input type="text" name="folder_name" placeholder="Введите название папки" required style="padding: 8px; width: 300px;">
                <button type="submit" name="create_folder" style="margin-left: 10px;">Создать папку</button>
            </form>
        </div>
    </div>



    			</div><!-- entry-content -->

    		</div>


    								<!-- Боковая панель -->
    								<aside class="sidebar">
    										<div class="widget">
    												<form role="search" method="get" class="search-form" action="/">
    														<label>
    																<span class="screen-reader-text">Найти:</span>
    																<input type="search" class="search-field" placeholder="Поиск…" value="" name="s">
    														</label>
    														<input type="submit" class="search-submit" value="Поиск">
    												</form>
    										</div>

    										<div class="widget">
    												<h3 class="widget-title">Свежие записи</h3>
    												<ul class="widget-list">
    														<li><a href="/%d0%b8%d1%82%d0%be%d0%b3%d0%b8-%d1%87%d0%b5%d0%bc%d0%bf%d0%b8%d0%be%d0%bd%d0%b0%d1%82%d0%b0-%d0%bf%d0%be-%d0%b0%d0%bb%d0%b3%d0%be%d1%80%d0%b8%d1%82%d0%bc%d0%b0%d0%bc-%d0%b2%d0%b8%d1%82%d1%82/">Итоги чемпионата по алгоритмам «Витте.Code»</a></li>
    														<li><a href="/%d0%bd%d0%be%d0%b2%d0%b0%d1%8f-%d0%bb%d0%b0%d0%b1%d0%be%d1%80%d0%b0%d1%82%d0%be%d1%80%d0%b8%d1%8f-vr-ar-%d0%be%d1%82%d0%ba%d1%80%d1%8b%d1%82%d0%b0-%d0%b2-%d0%ba%d0%b0%d0%bc%d0%bf%d1%83%d1%81%d0%b5/">Новая лаборатория VR/AR открыта в кампусе</a></li>
    														<li><a href="/%d0%be%d0%bf%d1%80%d0%be%d1%81-%d0%ba%d0%b0%d0%ba%d0%b8%d0%b5-%d1%82%d0%b5%d1%85%d0%bd%d0%be%d0%bb%d0%be%d0%b3%d0%b8%d0%b8-%d0%b2%d0%b0%d0%bc-%d0%b8%d0%bd%d1%82%d0%b5%d1%80%d0%b5%d1%81%d0%bd%d1%8b/" aria-current="page">Опрос: какие технологии вам интересны?</a></li>
    												</ul>
    										</div>

    										<div class="widget">
    												<h3 class="widget-title">Архивы</h3>
    												<ul class="widget-list">
    														<li><a href="/2025/01/">Январь 2025</a></li>
    														<li><a href="/2019/07/">Июль 2019</a></li>
    												</ul>
    										</div>
    								</aside>
    								</main>

    								<!-- Подвал сайта -->
    								<footer class="site-footer">
    								<div class="container">
    										<div class="footer-content">
    												<div class="footer-section">
    														<h3 class="footer-title">О нас!</h3>
    														<ul class="footer-links">
    																<li><a href="/a5213-contact/">Контакты</a></li>
    																<li><a href="#">Версия сайта для слабовидящих</a></li>
    														</ul>
    												</div>

    												<div class="footer-section">
    														<h3 class="footer-title">Последние новости</h3>
    														<ul class="footer-links">
    																<li><a href="/%d0%b8%d1%82%d0%be%d0%b3%d0%b8-%d1%87%d0%b5%d0%bc%d0%bf%d0%b8%d0%be%d0%bd%d0%b0%d1%82%d0%b0-%d0%bf%d0%be-%d0%b0%d0%bb%d0%b3%d0%be%d1%80%d0%b8%d1%82%d0%bc%d0%b0%d0%bc-%d0%b2%d0%b8%d1%82%d1%82/">Итоги чемпионата по алгоритмам «Витте.Code»</a></li>
    																<li><a href="/%d0%bd%d0%be%d0%b2%d0%b0%d1%8f-%d0%bb%d0%b0%d0%b1%d0%be%d1%80%d0%b0%d1%82%d0%be%d1%80%d0%b8%d1%8f-vr-ar-%d0%be%d1%82%d0%ba%d1%80%d1%8b%d1%82%d0%b0-%d0%b2-%d0%ba%d0%b0%d0%bc%d0%bf%d1%83%d1%81%d0%b5/">Новая лаборатория VR/AR открыта в кампусе</a></li>
    														</ul>
    												</div>

    												<div class="footer-section">
    														<h3 class="footer-title">Свежие записи</h3>
    														<ul class="footer-links">
    																<li><a href="/%d0%b8%d1%82%d0%be%d0%b3%d0%b8-%d1%87%d0%b9%d0%bc%d0%bf%d0%b8%d0%be%d0%bd%d0%b0%d1%82%d0%b0-%d0%bf%d0%be-%d0%b0%d0%bb%d0%b3%d0%be%d1%80%d0%b8%d1%82%d0%bc%d0%b0%d0%bc-%d0%b2%d0%b8%d1%82%d1%82/">Итоги чемпионата по алгоритмам «Витте.Code»</a></li>
    														</ul>
    												</div>
    										</div>

    										<div class="copyright">
    												<p>&copy; 2025 Student IT Community Юманова Мария Андреевна.</p>
    										</div>
    								</div>
    								</footer>
</body>
</html>
